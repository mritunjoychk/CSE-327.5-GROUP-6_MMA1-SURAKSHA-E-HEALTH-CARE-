<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>About Us</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>
         
*{
	margin:0;
	padding:0;
}
.logo {
	float: left;
}
	body{
	background:#c8eed9;
	background-size:cover;
}
.box-1{

       width:25%;
	   height:50%;
	   position:absolute;
	   background:#02475e;
	   left:35.5%;
	   top:25%;
       color:white;
	   text-align: center;
     margin:28px;
}

.box-1 p{
	color:#f8f4e1;
	 margin:18px;
	 font-size:20px;
}
.Footer{
    width: 100%;
    text-align: center;
    padding: 25% 0;
}
.Footer h3{
    margin-bottom: 10px;
    margin-top: 200px;
    font-weight: 30;
    font-weight: 30;
}
        
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
        <div class="box-1">
		<h1>About Us</h1>
		<p>Our website is an online based e-health care service. Through our website, you can contact with our listed doctors and also get blood from registered donors. We also provide home delivery service .We are here to provide you the best service 24 hours a day. We believe that happy customers are one of the reasons why an organization is moving forward.</p>
		</div>
        <section class="Footer">
    <a href="https://mail.google.com/mail/u/0/#inbox?compose=new"><h3> @Contact Us</h3></a>
<p> <br><br>This site is under construction  by NSUer!<br><br><br>Stay home,Stay safe.
             </p>
             </section>
    </body>
</html>
