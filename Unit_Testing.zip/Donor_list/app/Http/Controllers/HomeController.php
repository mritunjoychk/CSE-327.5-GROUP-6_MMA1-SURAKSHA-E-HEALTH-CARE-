<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

use App\Models\User;
use App\Models\Donor;

class HomeController extends Controller
{
   
       public function donor()
       {
       $data= donor::all();
       return view ('user.donor',compact('data'));
       }
}
